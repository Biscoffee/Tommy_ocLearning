//
//  Model.h
//  520（2）
//
//  Created by 吴桐 on 2025/5/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Model : NSObject
    @property (nonatomic, strong) NSMutableArray *xiyouMobileArray;
    @property (nonatomic, strong) NSMutableDictionary *xiyouMobileDict;
@end

NS_ASSUME_NONNULL_END
