//
//  XiyouMobilePerson+XiyouMobilePersonCategory.m
//  520（2）
//
//  Created by 吴桐 on 2025/5/22.
//

#import "XiyouMobilePerson+XiyouMobilePersonCategory.h"

@implementation XiyouMobilePerson (XiyouMobilePersonCategory)
- (NSDictionary *)toDictionary {
    return @{
        @"iOS": @(_iOS),
        @"web": @(_web),
        @"android": _android,
        @"server": _server
    };
}
@end
