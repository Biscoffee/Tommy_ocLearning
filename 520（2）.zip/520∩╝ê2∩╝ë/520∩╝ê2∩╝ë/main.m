//
//  main.m
//  520（2）
//
//  Created by 吴桐 on 2025/5/22.
//

#import <Foundation/Foundation.h>
#import "Singleton.h"
#import "XiyouMobilePerson.h"
#import "XiyouMobilePerson+XiyouMobilePersonCategory.h"
#import "Person.h"
#import "Model.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // 分类测试
        Person* q = [[Person alloc] initWithName:@"On" andage:190];
        NSLog(@"%@ %ld", q.name, (long)q.age);
        XiyouMobilePerson *testPerson = [[XiyouMobilePerson alloc]init];
        [testPerson setIOS:1];
        [testPerson setWeb:0];
        NSDictionary *info = [testPerson toDictionary];
        NSLog(@"分类返回字典：%@", info);

      //   数组操作
        Model *model = [[Model alloc] init];
        for (int i = 0; i < 5; i++) {
            XiyouMobilePerson *p = [[XiyouMobilePerson alloc] initWithName:[NSString stringWithFormat:@"人%d", i] age:20+i];
            [p setIOS:i+1];
            [p setWeb:i];
            [p setAndroid:@"安卓"];
            [p setServer:@"服务器"];
            [model.xiyouMobileArray addObject:p];
        }

        // 打印iOS最大的对象
//        XiyouMobilePerson *maxIOS = model.xiyouMobileArray[0];
//        for (XiyouMobilePerson *p in model.xiyouMobileArray) {
//            if ([p getIOS] > [maxIOS getIOS]) {
//                maxIOS = p;
//            }
//        }
//        NSLog(@"iOS值最大对象：%@", [maxIOS toDictionary]);
//
//        // 删除 range(2,3)
//        NSRange range = NSMakeRange(2, 3);
//        if (model.xiyouMobileArray.count >= 5) {
//            [model.xiyouMobileArray removeObjectsInRange:range];
//        }

        // 字典操作
        XiyouMobilePerson *iosPerson = @{@"key":@"iOS", @"Value":@"胖猫"};
        XiyouMobilePerson *AndroidPerson = @{@"key":@"Android", @"Value":@"乌萨奇"};
        XiyouMobilePerson *ServerPerson = @{@"key":@"Server", @"Value":@"奶龙"};


        // 集合操作
//        Person *p1 = [[Person alloc] initWithName:@"相同人" age:25];
//        Person *p2 = [p1 copy];
//
//        NSSet *personSet = [NSSet setWithObjects:p1, p2, nil];
//        NSLog(@"NSSet 内容：%@", personSet);
    }
    return 0;
}
