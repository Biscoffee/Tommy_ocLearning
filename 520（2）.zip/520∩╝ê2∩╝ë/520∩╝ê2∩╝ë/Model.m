//
//  Model.m
//  520（2）
//
//  Created by 吴桐 on 2025/5/22.
//

#import "Model.h"


@implementation Model
- (instancetype)init {
    if (self = [super init]) {
        _xiyouMobileArray = [NSMutableArray array];
        _xiyouMobileDict = [NSMutableDictionary dictionary];
    }
    return self;
}

-(id) initWithName

@end
