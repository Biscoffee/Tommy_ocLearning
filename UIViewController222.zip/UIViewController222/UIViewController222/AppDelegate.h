//
//  AppDelegate.h
//  UIViewController222
//
//  Created by 吴桐 on 2025/5/25.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

