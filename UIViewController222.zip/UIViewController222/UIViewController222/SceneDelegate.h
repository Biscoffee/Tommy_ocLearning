//
//  SceneDelegate.h
//  UIViewController222
//
//  Created by 吴桐 on 2025/5/25.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

