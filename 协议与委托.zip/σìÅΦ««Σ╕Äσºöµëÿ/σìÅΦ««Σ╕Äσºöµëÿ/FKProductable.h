//
//  FKProductable.h
//  协议与委托
//
//  Created by 吴桐 on 2025/5/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol FKProductable <NSObject>
-(NSData*) getProductTime;

@end

NS_ASSUME_NONNULL_END
