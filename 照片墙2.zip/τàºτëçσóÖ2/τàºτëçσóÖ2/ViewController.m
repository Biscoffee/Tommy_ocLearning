//
//  ViewController.m
//  照片墙2
//
//  Created by 吴桐 on 2025/6/4.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
