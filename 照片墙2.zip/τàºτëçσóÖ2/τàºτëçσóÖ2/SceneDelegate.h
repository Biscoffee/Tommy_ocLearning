//
//  SceneDelegate.h
//  照片墙2
//
//  Created by 吴桐 on 2025/6/4.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

